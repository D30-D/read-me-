<?php


    header('Location: ../auth/admin_login.php');

